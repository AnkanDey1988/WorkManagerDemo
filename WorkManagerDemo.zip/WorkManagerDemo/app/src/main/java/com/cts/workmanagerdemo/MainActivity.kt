package com.cts.workmanagerdemo

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color.Companion.White
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.Constraints
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.cts.workmanagerdemo.ui.theme.Purple40
import com.cts.workmanagerdemo.ui.theme.WorkManagerDemoTheme
import java.util.concurrent.TimeUnit


open class MainActivity : ComponentActivity() {

    lateinit var workManager: WorkManager

    private val buttonEnabled = mutableStateOf(true)

    private val WORK_REQ_TAG = "WorkReqTag"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WorkManagerDemoTheme {
                // A surface container using the 'background' color from the theme
                MyUI(onTimeReqClick = ::oneTimeReq,
                    oneTimeChainReqClick = ::oneTimeChainReq,
                    periodicReqClick = ::periodicReq,
                    cancelReqClick = ::cancelReq)
            }
        }

        init()
    }

    /**
     * Initiating workmanager instance
     */
    private fun init() {
        workManager = WorkManager.getInstance(this)

        // Listen workmanager status. It is a live data object and user can query with TAG/WorkRequest ID
        WorkManager.getInstance(this).getWorkInfosByTagLiveData(WORK_REQ_TAG)
            .observe(this) { workInfos ->
                if (workInfos != null && workInfos.size > 0) {
                    Log.i("WorkDemo", workInfos[0].state.name)
                    when(workInfos[0].state.name) {
                        "RUNNING" -> buttonEnabled.value = false
                        "ENQUEUED" -> buttonEnabled.value = false
                        "SUCCEEDED" -> {
                            buttonEnabled.value = true
                            val outputData = workInfos[0].outputData.getString("OUTPUT_DATA")
                            outputData?.let { Log.i("WorkDemo", it) }
                        }
                        "CANCELLED" -> buttonEnabled.value = true
                        else -> buttonEnabled.value = true
                    }
                }
            }

    }

    private fun oneTimeReq() {

        // Data that needs to be passed to Worker class
        val dataToPass = workDataOf(
            "KEY" to "Workmanager triggered"
        )

        // Set any constrain
        val constraint = Constraints.Builder()
            .setRequiresStorageNotLow(false)
            .setRequiresBatteryNotLow(true)
            .build()

        // Creating oneTimeRequest
        val work = OneTimeWorkRequestBuilder<MyWorker>()
            .addTag(WORK_REQ_TAG) // Adding TAG for querying Work status in future
            .setConstraints(constraint)
            .setInputData(dataToPass)
            .setInitialDelay(1, TimeUnit.MINUTES) // Initial delay for this request to start
            .build()

        workManager
            .beginWith(work)
            .enqueue()
    }

    private fun oneTimeChainReq() {

        val work1 = OneTimeWorkRequestBuilder<MyWorker>()
            .setInputData(workDataOf(
                "KEY" to "Workmanager triggered work1"
            ))
            .build()

        val work2 = OneTimeWorkRequestBuilder<MyWorker>()
            .setInputData(workDataOf(
                "KEY" to "Workmanager triggered work2"
            ))
            .build()

        val work3 = OneTimeWorkRequestBuilder<MyWorker>()
            .setInputData(workDataOf(
                "KEY" to "Workmanager triggered work3"
            ))
            .build()

        val work4 = OneTimeWorkRequestBuilder<MyWorker>()
            .setInputData(workDataOf(
                "KEY" to "Workmanager triggered work4"
            ))
            .build()

        val work5 = OneTimeWorkRequestBuilder<MyWorker>()
            .addTag(WORK_REQ_TAG)
            .setInputData(workDataOf(
                "KEY" to "Workmanager triggered work5"
            ))
            .build()

        // work1 and work2 will run in parallel. After both work completes, work3 will run, then
        // work4 and work5 will run in parallel
        workManager
            .beginWith(listOf(work1, work2))
            .then(work3)
            .then(listOf(work4, work5))
            .enqueue()
    }

    private fun periodicReq() {
        // Interval of 15 minutes
        val work = PeriodicWorkRequestBuilder<MyWorker>(15, TimeUnit.MINUTES)
            .addTag(WORK_REQ_TAG)
            .build()

        workManager.enqueue(work)
    }

    private fun cancelReq() {
        workManager.cancelAllWork()
    }

    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun MyUI(onTimeReqClick: ()-> Unit, oneTimeChainReqClick: ()-> Unit, periodicReqClick: ()-> Unit, cancelReqClick: ()-> Unit) {

        var buttonEnabled by buttonEnabled

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(text = "WorkManager Demo", color = White)
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Purple40)
                )
            }, content = {
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceEvenly,
                    modifier = Modifier.fillMaxSize()) {

                    Text(text = "Click on any button to run workmanager. " +
                            "Open LogCat and filter by \"WorkDemo\" to see the output. " +
                            "Cancel request anytime",
                        modifier = Modifier.padding(10.dp),
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp)


                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = {
                            buttonEnabled = false
                            onTimeReqClick()},
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Purple40,
                                contentColor = White),
                            enabled = buttonEnabled) {
                            Text(text = "OneTime",
                                fontSize = 16.sp)
                        }

                        TextViewInfo(str = "Output can be seen after 1 minutes")
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = {
                            buttonEnabled = false
                            oneTimeChainReqClick()},
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Purple40,
                                contentColor = White),
                            enabled = buttonEnabled) {
                            Text(text = "OneTime Chain Request",
                                fontSize = 16.sp)
                        }

                        TextViewInfo(str = "Output can be seen after each parallel work completes")
                    }


                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()) {

                        Button(onClick = {
                            buttonEnabled = false
                            periodicReqClick()},
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Purple40,
                                contentColor = White),
                            enabled = buttonEnabled) {
                            Text(text = "Periodic",
                                fontSize = 16.sp)
                        }

                        TextViewInfo(str = "Output can be seen in every 15 minutes interval")
                    }


                    Button(onClick = {
                        buttonEnabled = true
                        cancelReqClick()},
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Purple40,
                            contentColor = White),
                        enabled = !buttonEnabled) {
                        Text(text = "Cancel Request",
                            fontSize = 16.sp)
                    }
                }
            })
    }

    @Composable
    fun TextViewInfo(str: String) {
        Text(text = str,
            modifier = Modifier.padding(2.dp),
            textAlign = TextAlign.Center,
            fontSize = 12.sp)

    }


    @Preview(showBackground = true)
    @Composable
    fun GreetingPreview() {
        WorkManagerDemoTheme {
            MyUI(::oneTimeReq, ::oneTimeChainReq, ::periodicReq, ::cancelReq)
        }
    }
}