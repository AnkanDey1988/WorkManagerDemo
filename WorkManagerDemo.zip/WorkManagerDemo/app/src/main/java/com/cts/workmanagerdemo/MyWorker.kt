package com.cts.workmanagerdemo

import android.content.Context
import android.util.Log
import androidx.work.Data
import androidx.work.Worker
import androidx.work.WorkerParameters

class MyWorker(context: Context, userParameters: WorkerParameters) :
    Worker(context, userParameters) {


    override fun doWork(): Result {
        try {

            // Do any long running, deferrable task here
            val passedValue = inputData.getString("KEY")

            Log.i("WorkDemo: ", "$passedValue")

            val outputData = Data.Builder()
                .putString("OUTPUT_DATA", "SUCCESS")
                .build()

            return Result.success(outputData)
        } catch (e: Exception) {
            return Result.failure()
        }
    }
}